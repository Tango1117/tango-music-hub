# Tango Music Hub

A simple smart-link landing page that deep-links listeners into their preferred music app (app if installed, web player otherwise) and tracks clicks with a tiny serverless function.

## Quick Deploy (Vercel)
1. Create a new project in Vercel.
2. Upload this folder (or connect a GitHub repo).
3. Deploy. The function at `/api/track` will log events (visible in Vercel logs).

## Quick Deploy (Netlify)
1. Create a new site.
2. Drag & drop this folder.
3. Netlify will auto-detect the function in `netlify/functions/track.js`. The route `/api/track` is mapped via `netlify.toml`.

## Customize
- Replace the cover image URL in `index.html` (`og:image` and `<img class="cover">`) with your preferred artwork URL.
- Edit the LINKS object in `index.html` to add/remove platforms.
- UTM parameters are preserved and posted to `/api/track` for basic analytics.

## Notes
- For persistent analytics, plug in Vercel KV, Upstash, or any DB and store events in the function.
- Everything here follows platform terms—no forced plays or hidden behavior.
