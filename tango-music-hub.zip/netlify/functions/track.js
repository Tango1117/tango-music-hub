exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };
  const body = JSON.parse(event.body || '{}');
  console.log('analytics', body);
  return { statusCode: 200, body: JSON.stringify({ ok: true }) };
};
