export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ ok:false });
  try {
    const { event, platform, utm } = req.body || {};
    console.log('analytics', { event, platform, utm, ua: req.headers['user-agent'] });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok:false });
  }
}
